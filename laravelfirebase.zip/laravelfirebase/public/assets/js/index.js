var loc = window.location.pathname;
var dir = loc.substring(0, loc.lastIndexOf('/'));
//var project_path = window.location.origin + dir + '/';
var project_path = window.location.origin + '/';
// Initialize Firebase
var config = {apiKey: "AIzaSyBcO09ING8RF7BnC9aXjPue1vJfZkwl_os",authDomain: "cityhuntdevelop.firebaseapp.com",databaseURL: "https://cityhuntdevelop.firebaseio.com",storageBucket: "cityhuntdevelop.appspot.com"};
firebase.initializeApp(config);

function login(){
	var userEmail =  $('#email_field').val();
	var userPass =  $('#password_field').val();
	if(userEmail != '')
	{  
		if(emailIsValid(userEmail) == false){
			$('#email_field').focus();
			alert('Email not valid');
			return false;
		}
	}else{
		alert("Please enter email");
		$('#email_field').focus();
		return false;
	}
	if(userPass == ''){
		alert("Please enter password");
		$('#password_field').focus();
		return false;
	}
	firebase.auth().signInWithEmailAndPassword(userEmail, userPass).catch(function(error) {
		// Handle Errors here.
		//var errorCode = error.code;
		var errorMessage = error.message;
		alert("Error : " + errorMessage);
		return false;
	});
	firebase.auth().onAuthStateChanged(function(user) {
		if (user){
			// User is signed in.
			window.location.href = project_path + "games";
		}
	});
}

function loginKeyUp(e) {
	e.which = e.which || e.keyCode;
	if (e.which == 13) {
		login();
	}
}  

function emailIsValid (email) {
   return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}

function signup(){
	var userName =  $('#name_field').val();
	var userEmail =  $('#email_field').val();
	var userPass =  $('#password_field').val();
	var userRePass =  $('#re_type_password_field').val();
	if(userName == '')
	{
		alert("Required Name");
		$('#name_field').focus();
		return false;
	}
	if(userEmail != '')
	{  
		if(emailIsValid(userEmail) == false){
			$('#email_field').focus();
			alert('Email not valid');
			return false;
		}
	}else{
		alert("Required email");
		$('#email_field').focus();
		return false;
	}
	
	if(userPass == ''){
		alert("Required password");
		$('#password_field').focus();
		return false;
	}
	if(userRePass == ''){
		alert("Required confirm password");
		$('#re_type_password_field').focus();
		return false;
	}
	
	if(userPass != '' && userRePass != ''){
		if(userPass == userRePass){
			//Create User with Email and Password
			firebase.auth().createUserWithEmailAndPassword(userEmail, userPass).then(function(user){
				user.updateProfile({
					displayName: userName
				}).then(function() {
					// Update successful.
				}, function(error) {
					// An error happened.
				});     
				window.location.href = project_path;				
			}, function(error){
				// Handle Errors here.
				var errorCode = error.code;
				var errorMessage = error.message;
				if (errorCode == 'auth/weak-password') {
					alert('The password is too weak.');
				} else {
					console.error(error);
				}
			});
		}else{
			alert("Confirm Password not matched"); 
			$('#re_type_password_field').focus();
			return false;
		}
	}
}

function signKeyUp(e) {
	e.which = e.which || e.keyCode;
	if (e.which == 13) {
		signup();
	}
} 

function logout(){
	firebase.auth().signOut()
	.then(function() {
	  // Sign-out successful.
	  window.location.href = project_path;
	  console.log('User Logged Out!');
	}).catch(function(error) {
	  // An error happened.
	  console.log(error);
	});	
}

//var database = firebase.database();
