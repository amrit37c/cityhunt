$(document).ready(function(){

    $(".chlng-val").map(function(){
        var ctype = $("#challenge_type"+this.value).val(); 
        if (ctype == "txt") {
            $("#txt" +this.value).show();
            $("#video" +this.value+"*").hide();
            $("#photo" +this.value).hide();
            $("#mcq" +this.value).hide();
        } else if (ctype == "photo") {
            $("#photo" +this.value).show();
            $("#txt" +this.value).show();
            $("#video" +this.value+"*").hide();
            $("#mcq" +this.value).hide();
        } else if (ctype == "video") {
            $("#video" +this.value+"*").show();
            $("#txt" +this.value).hide();
            $("#photo" +this.value).hide();
            $("#mcq" +this.value).hide();
        } else if (ctype == "mcq") {
            $("#mcq" +this.value).show();
            $("#txt" +this.value).hide();
            $("#video" +this.value+"*").hide();
            $("#photo" +this.value).hide();
        } else {
            $("#video" +this.value+"*").hide();
            $("#photo" +this.value).hide();
            $("#qrc" +this.value).hide();
            $("#tri" +this.value).hide();
            $("#mcq" +this.value).hide();
            $("#txt"  +this.value).show();
        }
    });

    /*** load editor ***/
    /*$('.summernote').summernote({
        placeholder: '',
        tabsize: 2,
        height: 50,
        toolbar: [
            ['font', ['bold', 'underline', 'italic']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['table', ['table']],
            ['insert', ['link', 'picture', 'video']]
        ]
    });*/
    $('.summernote').summernote();
    $('.challengeform').sortable({
        helper: 'clone',
        handle: "h6",
        axis: 'y',
    });

    
     /*** Create clone of challange ***/
    $('#but_add').click(function(){
        var regex = /^(.+?)(\d+)$/i;
        var cloneIndex = $(".challengeform").length;
        cloneIndex++;
        var newInnerDiv = $(".challengeform:last").clone(true)
        .find("input[type=text], textarea").val("").end().removeAttr('selected')
        .appendTo('.challengeform:last')
        .attr("id", "challengeform" +  cloneIndex)
        .find("*")
        .each(function(){
            var id = this.id || "";
            var match = id.match(regex) || [];
            if (match.length == 3) {
                this.id = match[1] + (cloneIndex);
            }
        })
        // first get rid of the summernote editor
        .find('.div_main_input:last').summernote('destroy');
        // initialize summernote again
        $('.challengeform:last .div_main_input').find('.summernote').summernote();
        // finally, remove the extra code created by summernote
        $('.div_main_input:last .card').nextUntil().remove();
        
        //form settings
        $('#challenge'+cloneIndex).val(cloneIndex);
        $('#position'+cloneIndex).val(cloneIndex);
        $("#myform"+ cloneIndex + " :input").prop("disabled", false); 
        $("#challenge_key"+ cloneIndex).val("");
        $("#image"+ cloneIndex).hide();
        $("#save" + cloneIndex).prop("checked", true);

        //position setting
        $('#challengeform'+cloneIndex).sortable({
            helper: 'clone',
            // start: function(event, ui) {
            //     //ui.item.startPos = ui.item.index();
            //     $('#position'+cloneIndex).val(ui.item.index()+1);
            // },
            // stop: function(event, ui) {
            //     //alert(ui.item.index()+1);
            // }
        });    
    });

    /*** load datatable  ***/
    $('#myTable').DataTable({
      "order": [[ 3, "desc" ]],
      "paging": true,	  
      "searching": false,
      "ordering": true,
      "info": false,
      "lengthChange": false,
      "autoWidth": true,
    });
});

// Show hide Challange type div function
function divShowHide(ctid, optval) {
    var matches = ctid.match(/(\d+)/);
    var id = matches[0];
    $("#video" + id + "*").hide();
    $("#photo" + id).hide();
    $("#qrc" + id).hide();
    $("#tri" + id).hide();
    $("#mcq" + id).hide();
    $("#txt" + id).hide();
    if (optval) {
        $("#" + optval + id).show();
        if (optval == 'photo' || optval == 'qrc' || optval == 'tri') {
            $("#txt" + id).show();
        }
        if (optval == 'video') {
            $("#video" + id + "*").show();
        }
    } else {
        $("#txt" + id).show();
    }
}

function printErrorMsg(msg) {
    $(".print-error-msg").find("ul").html('');
    $(".print-error-msg").css('display', 'block');
    $.each(msg, function(key, value) {
        $(".print-error-msg").find("ul").append('<li>' + value + '</li>');
    });
}