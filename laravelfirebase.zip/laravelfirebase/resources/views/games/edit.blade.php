@extends('layout.mainlayout')
@section('content')
<div class="container homec">
    <div class="row">

        <div class="col-md-3 center cityhunt-colmn">
            <img src="{{ asset('assets/images/cityHUNT-logo-2020.svg') }}" class="login-logo dashboard-logo">
            <input type="text" placeholder="search" class="gameCreate-input chlng">
            <div class="select-text">
                <select class="dropdown-challenge">
                    <option>Jump TO Challenge</option>
                    <option>Jump TO Challenge</option>
                    <option>Jump TO Challenge</option>
                    <option>Jump TO Challenge</option>
                    <option>Jump TO Challenge</option>
                </select>

                <p class="createGame-input">
                    <a data-toggle="tooltip" data-placement="bottom"
                        title="On click on Add button a user can create New Challenge" class="tooltip_team"
                        id="but_add">Add new Challenge</a>
                </p>
            </div>
        </div>

        <div class="col-md-9">
            <div class="row header header-game team-header">
                <div class="col-md-8">
                    <span class="game-header-font">GAME TITLE</span>
                    <input type="text" id="game_title" name="game_title" class="challenge-search-input"
                        value="{{ old('game_title', $data['game_title']) }}">

                    <div class=" header-line-height">
                        <span class="game-header-font">Tags</span>
                        <input type="text" id="game_tags" name="game_tags"
                            class="challenge-moderator-input tags-inpt challenge-search-input"
                            value="{{ old('game_tags', $data['game_tags']) }}">
                        <span class="game-header-font">GAME CODE</span>
                        <input type="text" id="game_code" name="game_code"
                            class="challenge-moderator-input game-code-inpt challenge-search-input"
                            value="{{ old('game_code', $data['game_code']) }}">
                    </div>
                </div>
                <div class="col-md-4 remove-padding">
                    <div class="moderator-div">
                        <span class="game-header-font">MODERATORS</span>
                        <input type="text" id="moderators" name="moderators"
                            class="challenge-search-input challenge-moderator-input moderate-inpt"
                            value="{{ old('moderators', $data['moderators']) }}">
                    </div>
                    <div class="leadarboard-div header-line-height">
                        <span class="game-header-font toogle-btn ">LEADERBOARD</span>
                        <label class="switch active-toogle leaderboard-label">
                            <input type="checkbox" id="leaderboard" name="leaderboard" class="my_tgl_blue"
                                {{ ($data['leaderboard'] == 'on') ? 'checked':'' }}>
                            <span class="slider round"></span>
                        </label>

                        <span class="game-header-font toogle-btn active-btn-header">ACTIVE</span>
                        <label class="switch active-toogle active-header-label">
                            <input type="checkbox" id="active_deactive" name="active_deactive" class="my_tgl_blue"
                                {{ ($data['active_deactive'] == 'Active') ? 'checked':'' }}>
                            <span class="slider round"></span>
                        </label>
                    </div>
                </div>
            </div>

            <div id="challengeDiv">

                <div class="first-challenge">
                    <div class="alert alert-success successmsg" style="display:none;">
                    </div>
                    <div class="alert alert-danger print-error-msg" style="display:none;">
                        <ul></ul>
                    </div>
                </div>

                @if(!empty($data['challenges']))
                @foreach($data['challenges'] as $ckey => $cdata)

                <!-- ############ Challange  ############ -->
                <div class="forms body-chl challengeform" id="challengeform{{ $cdata['challenge_id'] ?? '' }}">
                    <form id="myform{{ $cdata['challenge_id'] ?? '' }}" method="POST"
                        action="{{ route('games.update', [$id]) }}" enctype="multipart/form-data" autocomplete="off">
                        {{ csrf_field() }}
                        <input name="_method" type="hidden" value="PATCH">
                        <div class="form_one input-form">
                            <div class="row">

                                <div class="col-md-5">
                                    <div class="challange_badge_div row">
                                        <div class="left_challange_badge_div">
                                            <h6 style="cursor: all-scroll;"> Challenge </h6>
                                            <input type="text" name="challenge"
                                                value="{{ $cdata['challenge_id'] ?? '' }}"
                                                id="challenge{{ $cdata['challenge_id'] ?? '' }}" class="chlng-val"
                                                maxlength="2">
                                        </div>
                                        <input type="hidden" name="challenge_key"
                                            id="challenge_key{{ $cdata['challenge_id'] ?? '' }}" value="{{ $ckey }}">
                                        <div class="challange_badge_input">
                                            <input type="text" name="challenge_title"
                                                id="challenge_title{{ $cdata['challenge_id'] ?? '' }}"
                                                placeholder="Challange Title"
                                                value="{{ old('challenge_title', $cdata['challenge_title']) }}">
                                        </div>
                                    </div>
                                    <input type="hidden" name="position" id="position{{ $cdata['challenge_id'] ?? '' }}"
                                        value="{{ $cdata['challenge_id'] ?? '' }}">
                                    <img class="img_br_news" src="{{ asset('assets/images/br_news.jpg') }}">
                                    <span>
                                        <select name="challenge_type"
                                            id="challenge_type{{ $cdata['challenge_id'] ?? '' }}"
                                            onchange="divShowHide(this.id, this.value)">
                                            <option value="">Choose Option</option>
                                            <option value="txt"
                                                {{ ($cdata['challenge_type'] == 'txt') ? 'selected':'' }}>Text</option>
                                            <option value="video"
                                                {{ ($cdata['challenge_type'] == 'video') ? 'selected':'' }}>Video
                                            </option>
                                            <option value="photo"
                                                {{ ($cdata['challenge_type'] == 'photo') ? 'selected':'' }}>Photo
                                            </option>
                                            <option value="mcq"
                                                {{ ($cdata['challenge_type'] == 'mcq') ? 'selected':'' }}>Multiple
                                                Choice</option>
                                            <option value="qrc"
                                                {{ ($cdata['challenge_type'] == 'qrc') ? 'selected':'' }}>QR Code
                                            </option>
                                            <option value="tri"
                                                {{ ($cdata['challenge_type'] == 'tri') ? 'selected':'' }}>Trivia
                                            </option>
                                        </select>
                                    </span>

                                    <div class="text_qsn_btn">
                                        <p> Does this clue have a location ? </p>
                                        <label class="switch location-switch check_style">
                                            <input type="checkbox" name="clue_location"
                                                id="clue_location{{ $cdata['challenge_id'] ?? '' }}">
                                            <span class="slider round"></span>
                                        </label>
                                    </div>

                                    <!--video-->
                                    <div class="video box" id="video{{ $cdata['challenge_id'] ?? '' }}">
                                        <input type="text" name="location"
                                            id="location{{ $cdata['challenge_id'] ?? '' }}" class="location_img_input"
                                            placeholder="Location"
                                            value="{{-- old('location', $cdata['location']) --}}">
                                        <button type="button" class="search-btn"> Search </button>
                                        <img id="img_loc" src="{{ asset('assets/images/Group 43.svg') }}">
                                    </div>
                                    <!--video-->

                                    <div class="left-icon" id="left-icon{{ $cdata['challenge_id'] ?? '' }}">
                                        <i class="fa fa-file-o fnt_asm_stngs fa-lg" aria-hidden="true"></i>
                                        <i class="fa fa-clone fnt_asm_stngs fa-lg aaa" aria-hidden="true"></i>
                                        <i class="fa fa-file-o fnt_asm_stngs fa-lg" aria-hidden="true"></i>
                                        <i class="fa fa-trash-o fnt_asm_stngs fa-lg" aria-hidden="true"></i>
                                    </div>

                                    <span class="lock_challange lock_challange_one"
                                        id="lock_challange_one{{ $cdata['challenge_id'] ?? '' }}">
                                        <span> Locked by Challange</span>
                                        <span class="p_select">
                                            <select name="locked_by" id="locked_by{{ $cdata['challenge_id'] ?? '' }}">
                                                <option>None</option>
                                            </select>
                                        </span>
                                    </span>
                                </div>

                                <div class="col-md-7">
                                    <div class="div_main_input">
                                        <textarea name="challenge_desc"
                                            id="summernote{{ $cdata['challenge_id'] ?? '' }}" class="summernote"
                                            cols="30" rows="10">{{ $cdata['challenge_desc'] ?? ''}}</textarea>
                                    </div>

                                    <!--text-->
                                    <div class="txt box" id="txt1">
                                        <textarea id="challenge_answer{{ $cdata['challenge_id'] ?? '' }}"
                                            name="challenge_answer" placeholder="Answers"
                                            class="answers_input_div">{{ $cdata['challenge_answer'] ?? '' }}</textarea>
                                    </div>
                                    <!--text-->

                                    <!--video-->
                                    <div class="video box" id="video{{ $cdata['challenge_id'] ?? '' }}">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <span class="sub-para"> Is there a Video/Image example? </span>
                                                <label class="switch video-label check_style">
                                                    <input type="checkbox" name="video_image"
                                                        id="video_image{{ $cdata['challenge_id'] ?? '' }}">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <span class="sub-para"> Example video Address </span>
                                                <span> <input class="example-video-addr" name="video_image_url"
                                                        id="video_image_url{{ $cdata['challenge_id'] ?? '' }}"
                                                        value="{{ $cdata['video_image_url'] ?? '' }}"></span>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <span class="sub-para"> Video length </span>
                                                <select class="example-video-section" name="video_length"
                                                    id="video_length{{ $cdata['challenge_id'] ?? '' }}">
                                                    <option value="">20s</option>
                                                    <option value="10s">10s</option>
                                                    <option value="20s">20s</option>
                                                </select>
                                            </div>
                                        </div><br><br>
                                    </div>
                                    <!--video-->

                                    <!--Image-->
                                    <div class="row photo box" id="photo{{ $cdata['challenge_id'] ?? '' }}">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    @if(!empty($cdata['image_name']))
                                                    <img src="/images/{{ $cdata['image_name'] ?? '' }}"
                                                        class="img-thumbnail" width="400" height="300" id="image{{ $cdata['challenge_id'] ?? '' }}"/>
                                                    @else
                                                    <input name="image_url"
                                                        id="image_url{{ $cdata['challenge_id'] ?? '' }}"
                                                        class="challenge-five-input">
                                                    <span id="uploaded_image{{ $cdata['challenge_id'] ?? '' }}"
                                                        style="display:none;"></span>
                                                    @endif
                                                </div>
                                                <div class="col-md-6"><input type="file"
                                                        id="select_file{{ $cdata['challenge_id'] ?? '' }}"
                                                        name="select_file" class="upload-png-btn">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="align-center">
                                                <p class="imge-overlay img-overly-second">Image Overlay Is:</p><br>
                                                <span class="imge-overlay">Floating</span>
                                                <span>
                                                    <label class="switch check_style floating-label">
                                                        <input type="checkbox" name="image_overlay"
                                                            id="image_overlay{{ $cdata['challenge_id'] ?? '' }}">
                                                        <span class="slider round"></span>
                                                    </label>
                                                </span>
                                                <span class="imge-overlay">Fullscreen</span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Image-->

                                    <!--MCQ-->
                                    <div class="mcq box" id="mcq{{ $cdata['challenge_id'] ?? '' }}">
                                        <div class="row">
                                            <div class="col-md-12"><input class="challenge-six-inputs"></div>
                                            <label class="challengesix-labelone switch check_style">
                                                <input type="checkbox" name="mcq_1_ans"
                                                    id="mcq_1_an{{ $cdata['challenge_id'] ?? '' }}">
                                                <span class="slider round"></span>
                                            </label>
                                            <span class="chllengesix-answer">Answer "1</span>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12"><input class="challenge-six-inputs"></div>
                                            <label class="challengesix-labelone switch check_style">
                                                <input type="checkbox" name="mcq_2_ans"
                                                    id="mcq_2_ans{{ $cdata['challenge_id'] ?? '' }}">
                                                <span class="slider round"></span>
                                            </label>
                                            <span class="chllengesix-answer">Answer "2</span>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12"><input class="challenge-six-inputs"></div>
                                            <label class="challengesix-labelone switch check_style">
                                                <input type="checkbox" name="mcq_3_ans"
                                                    id="mcq_3_ans{{ $cdata['challenge_id'] ?? '' }}">
                                                <span class="slider round"></span>
                                            </label>
                                            <span class="chllengesix-answer">Answer "3</span>
                                        </div>
                                    </div>
                                    <!--MCQ-->

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="Show_submission">
                                                <p class="show-sub-para"> Show submission in Streams: </p>
                                                <label class="switch body-switches check_style">
                                                    <input type="checkbox" class="save"
                                                        id="save{{ $cdata['challenge_id'] ?? '' }}" checked
                                                        onchange="formUSubmit(this.id);">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </form>
                    @endforeach
                    </div>

                @endif
            </div>
        </div>
    </div>
</div>

@section('scripts')
<script>
function formUSubmit(sid) {
    var matches = sid.match(/(\d+)/);
    //if (matches[0] == '' || matches[0] == 0) { return false; }
    var cid = matches[0];
    var gtitle = $("#game_title").val();
    if (gtitle == '') {
        $("#game_title").focus();
    }
    var gtags = $('#game_tags').val();
    if (gtags == '') {
        $("#game_tags").focus();
    }
    var gcode = $('#game_code').val();
    if (gcode == '') {
        $("#game_code").focus();
    }
    var gmode = $('#moderators').val();
    if (gmode == '') {
        $("#moderators").focus();
    }
    var glboard = $('#leaderboard').val();
    var gad = $('#active_deactive').val();
    var gamedata = {
        'game_title': gtitle,
        'game_tags': gtags,
        'game_code': gcode,
        'moderators': gmode,
        'leaderboard': glboard,
        'active_deactive': gad
    };
    var form_data = new FormData(document.getElementById("myform" + cid));
    for (var key in gamedata) {
        form_data.append(key, gamedata[key]);
    }
    $.ajax({
        url: "{{ route('games.update',[$id]) }}",
        type: "post",
        data: form_data,
        dataType: 'JSON',
        contentType: false,
        cache: false,
        processData: false,
        headers: {
            'X-CSRF-Token': '{{ csrf_token() }}',
        },
        success: function(data) {
            //console.log(data);
            if ($.isEmptyObject(data.error)) {
                $(".print-error-msg").hide();
                $(".successmsg").html(data.success).show().delay(10000).fadeOut(800);
                $("#image_url" + cid).hide();
                $("#uploaded_image" + cid).html(data.uploaded_image).show();
                $("#myform" + cid + " :input").prop("disabled", true);
                $("#save" + cid).removeAttr('checked');
            } else {
                printErrorMsg(data.error);
                $("#image_url" + cid).show();
                $("#save" + cid).prop('checked', function(_, checked) {
                    return !checked;
                });
            }
        }
    });
}
</script>
@show
@endsection