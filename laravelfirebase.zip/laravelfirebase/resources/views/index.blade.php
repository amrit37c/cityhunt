@extends('layout.mainlayout')
@section('content')
<div class="login-background">
   <div class="container">
   
        <div class="row">
            <div class="col-md-4">

            </div>
            <div class="col-md-4 center">
                <div class="login-form-bck login-page-s">
                    <p>
                    <img src="{{ asset('assets/images/cityHUNT-logo-2020.svg') }}" class="login-logo">
                </p>
                    <p>
                    <input type="text" placeholder="Email" class="login-inputs" id="email_field">
                </p>
                    <input type="password" placeholder="Password" class="login-inputs" id="password_field" onkeyup="loginKeyUp(event)">
                    <p>
                        <button class="login-btn" onclick="login()">LOGIN</button>
					</p>
                </div>
                <div>
                    
                </div>
                <a href="{{ URL::route('register') }}" id="create-acc">Create Account</a>

            </div>
            <div class="col-md-4">
            
            </div>
        </div>

    </div>
  </div>  
@endsection
