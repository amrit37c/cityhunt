<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
//use App\Http\Requests\GamesStoreRequest;
//use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;

class GamesController extends Controller
{
    public $database;
    public function __construct() {      
        $this->database = \App::call('App\Http\Controllers\FirebaseController@index');
    }

    public function index()
    {
        $reference  =  $this->database->getReference('games');
        $data = $reference->getvalue();
        return view('games/index', compact('data'));
    }


    public function get(int $userID = NULL){    
        if (empty($userID) || !isset($userID)) { return FALSE; }
        if ($this->database->getReference($this->dbname)->getSnapshot()->hasChild($userID)){
            return $this->database->getReference($this->dbname)->getChild($userID)->getValue();
        } else {
            return FALSE;
        }
    }
 
 
    public function insert(array $data) {
        if (empty($data) || !isset($data)) { return FALSE; }
        foreach ($data as $key => $value){
            $this->database->getReference()->getChild($this->dbname)->getChild($key)->set($value);
        }
        return TRUE;
    }
 
 
    public function delete(int $userID) {
        if (empty($userID) || !isset($userID)) { return FALSE; }
        if ($this->database->getReference($this->dbname)->getSnapshot()->hasChild($userID)){
            $this->database->getReference($this->dbname)->getChild($userID)->remove();
            return TRUE;
        } else {
            return FALSE;
        }
    }


    public function create()
    {
        return view('games/create');
    }


    public function store(request $request)
    {
        $validator = Validator::make($request->all(), [
            'game_title' => 'required',
            'game_tags' => 'required',
            'game_code' => 'required',
            'moderators' => 'required',
            'challenge_title' => 'required',
            'challenge_type' => 'required',
            'select_file' => 'image|mimes:jpeg,png,jpg,gif|max:2048'
        ]);

        if ($validator->fails())
        {
            return response()->json(['error'=>$validator->errors()->all()]);
        }
        else
        {
            $exist_gameId = '';
            if(!empty($request->game_code)){
                $checkgame = $this->database->getReference('games')->orderByChild("game_code")
                    ->equalTo($request->game_code)->getValue();
                $exist_gameId = array_key_first($checkgame); 
            }

            if($exist_gameId == ''){
                $active_deactive = ($request->active_deactive == 'on') ? 'Active' : 'Deactive';
                $leaderboard = ($request->leaderboard == 'on') ? 'on' : 'off';
                $newgame = $this->database->getReference('games')
                    ->push([
                        'game_title' => $request->game_title ,
                        'moderators' => $request->moderators,
                        'game_tags' => $request->game_tags,
                        'game_code' => $request->game_code,
                        'leaderboard' => $leaderboard,
                        'active_deactive' => $active_deactive,
                        'date' => now()
                    ])->getKey();
                $game_id = $newgame;
            }else{
                $game_id = $exist_gameId;
            }

            //If challenge type photo
            if($request->challenge_type == 'photo'){

                //image upload 
                $image_name = $uploaded_image = '';
                if(!empty($request->file('select_file'))){
                    $image = $request->file('select_file');
                    $image_name = rand() . '.' . $image->getClientOriginalExtension();
                    $image->move(public_path('images'), $image_name);
                }

                $challengeData = [
                    'game_id' => $game_id,
                    'challenge_id' => $request->challenge,
                    'challenge_title' => $request->challenge_title,
                    'challenge_type' => $request->challenge_type,
                    'challenge_desc' => $request->challenge_desc,
                    'challenge_answer' => $request->challenge_answer,
                    'locked_by' => $request->locked_by,
                    'image_name' => $image_name,
                    'image_overlay' => $request->image_overlay
                ];
             
            //If challenge type video    
            }else if($request->challenge_type == 'video'){

                $challengeData = [
                    'game_id' => $game_id,
                    'challenge_id' => $request->challenge,
                    'challenge_title' => $request->challenge_title,
                    'challenge_type' => $request->challenge_type,
                    'challenge_desc' => $request->challenge_desc,
                    'challenge_answer' => $request->challenge_answer,
                    'location' => $request->location,
                    'locked_by' => $request->locked_by,
                    'video_image' => $request->video_image,
                    'video_image_url' => $request->video_image_url,
                    'video_length' => $request->video_length
                ];

            //If challenge type MCQ 
            }else if($request->challenge_type == 'mcq'){

                $challengeData = [
                    'game_id' => $game_id,
                    'challenge_id' => $request->challenge,
                    'challenge_title' => $request->challenge_title,
                    'challenge_type' => $request->challenge_type,
                    'challenge_desc' => $request->challenge_desc,
                    'challenge_answer' => $request->challenge_answer,
                    'location' => $request->location,
                    'locked_by' => $request->locked_by,
                    'mcq_1_ans' => $request->mcq_1_ans,
                    'mcq_2_ans' => $request->mcq_2_ans,
                    'mcq_3_ans' => $request->mcq_3_ans
                ];

            //If challenge type Text 
            }else{
                $challengeData = [
                    'game_id' => $game_id,
                    'challenge_id' => $request->challenge,
                    'challenge_title' => $request->challenge_title,
                    'challenge_type' => $request->challenge_type,
                    'challenge_desc' => $request->challenge_desc,
                    'challenge_answer' => $request->challenge_answer,
                    'location' => $request->location,
                    'locked_by' => $request->locked_by
                ];
            }
            
            $newchallenge = $this->database->getReference('challenge')->push($challengeData);
            if($newchallenge){
                $challengeno = "Challenge ".$request->challenge;
                if(!empty($image_name)){
                    return response()->json([
                        'success'   => $challengeno.' is successfully created!',
                        'uploaded_image' => '<img src="/images/'.$image_name.'" class="img-thumbnail" width="300" />'
                    ]);
                }else{
                    return response()->json([
                        'success'=> $challengeno.' is successfully created!',
                        'uploaded_image' => ''
                    ]);
                }
            }
        }
    }


    public function edit($id)
    {
        $data = $this->database->getReference('games')->getChild($id)->getValue();
        $data['challenges'] = $this->database->getReference('challenge')->orderByChild("game_id")
                                ->equalTo($id)->getValue();
        // $sdf = $this->database->getReference('challenge')->orderByChild("game_id")
        //                 ->equalTo('-M6ZAEua_dTiXiQvUlIY')->getValue();
        // dd(count($sdf));                                                
        return view('games/edit', compact('id','data'));
    }

    
    public function update(request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'game_title' => 'required',
            'game_tags' => 'required',
            'game_code' => 'required',
            'moderators' => 'required',
            'challenge_title' => 'required',
            'challenge_type' => 'required',
            'select_file' => 'image|mimes:jpeg,png,jpg,gif|max:2048'
        ]);

        if ($validator->fails())
        {
            return response()->json(['error'=>$validator->errors()->all()]);
        }
        else
        {
            $game_id = $id;
            $challenge_key = $request->challenge_key;
            
            //If challenge type photo
            if($request->challenge_type == 'photo'){

                //image upload 
                $image_name = $uploaded_image = '';
                if(!empty($request->file('select_file'))){
                    $image = $request->file('select_file');
                    $image_name = rand() . '.' . $image->getClientOriginalExtension();
                    $image->move(public_path('images'), $image_name);
                }

                $challengeData = [
                    'game_id' => $game_id,
                    'challenge_id' => $request->challenge,
                    'challenge_title' => $request->challenge_title,
                    'challenge_type' => $request->challenge_type,
                    'challenge_desc' => $request->challenge_desc,
                    'challenge_answer' => $request->challenge_answer,
                    'locked_by' => $request->locked_by,
                    'image_name' => $image_name,
                    'image_overlay' => $request->image_overlay
                ];
             
            //If challenge type video    
            }else if($request->challenge_type == 'video'){

                $challengeData = [
                    'game_id' => $game_id,
                    'challenge_id' => $request->challenge,
                    'challenge_title' => $request->challenge_title,
                    'challenge_type' => $request->challenge_type,
                    'challenge_desc' => $request->challenge_desc,
                    'challenge_answer' => $request->challenge_answer,
                    'location' => $request->location,
                    'locked_by' => $request->locked_by,
                    'video_image' => $request->video_image,
                    'video_image_url' => $request->video_image_url,
                    'video_length' => $request->video_length
                ];

            //If challenge type MCQ 
            }else if($request->challenge_type == 'mcq'){

                $challengeData = [
                    'game_id' => $game_id,
                    'challenge_id' => $request->challenge,
                    'challenge_title' => $request->challenge_title,
                    'challenge_type' => $request->challenge_type,
                    'challenge_desc' => $request->challenge_desc,
                    'challenge_answer' => $request->challenge_answer,
                    'location' => $request->location,
                    'locked_by' => $request->locked_by,
                    'mcq_1_ans' => $request->mcq_1_ans,
                    'mcq_2_ans' => $request->mcq_2_ans,
                    'mcq_3_ans' => $request->mcq_3_ans
                ];

            //If challenge type Text 
            }else{
                $challengeData = [
                    'game_id' => $game_id,
                    'challenge_id' => $request->challenge,
                    'challenge_title' => $request->challenge_title,
                    'challenge_type' => $request->challenge_type,
                    'challenge_desc' => $request->challenge_desc,
                    'challenge_answer' => $request->challenge_answer,
                    'location' => $request->location,
                    'locked_by' => $request->locked_by
                ];
            }

            //Check challenge exist or not
            //$checkchallenge = $this->database->getReference('challenge')->getChild($challenge_key)->getValue();
            
            //if challenge exist then update otherwise add new challenge
            if(trim($challenge_key) != ''){ 
                $challengeqry = $this->database->getReference('challenge')->getChild($challenge_key)->set($challengeData); 
            }else{
                $challengeqry = $this->database->getReference('challenge')->push($challengeData);
            }
            if($challengeqry){
                $challengeno = "Challenge ".$request->challenge;
                if(!empty($image_name)){
                    return response()->json([
                        'success'   => $challengeno.' is successfully updated!',
                        'uploaded_image' => '<img src="/images/'.$image_name.'" class="img-thumbnail" width="300" />'
                    ]);
                }else{
                    return response()->json([
                        'success'=> $challengeno.' is successfully updated!',
                        'uploaded_image' => ''
                    ]);
                }
            }
        }
    }

}


// $users = new Users();
// var_dump($users->insert([
//    'name' => 'John',
//    'email' => 'john@gmail.com',
//    'password' => 'Smith'
// ]));
// var_dump($users->get(2));
// //var_dump($users->delete(2));