<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Kreait\Firebase;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;

class FirebaseController extends Controller
{
    /**
     * Creating Connection with firebase database.
     *
     * @return \Illuminate\Http\Response
     */
    function index()
    {
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/cityhuntdevelop-firebase-adminsdk-g48v3-f4510b3da8.json');
        $firebase = (new Factory)
            ->withServiceAccount($serviceAccount)
            ->withDatabaseUri('https://cityhuntdevelop.firebaseio.com/')
            ->create();
        $database = $firebase->getDatabase();
        return $database;

        // $newPost = $database->getReference('games')
        //     ->push([
        //         'title' => 'Game Name' ,
        //         'moderators' => 'Game stage'
        //     ]);
        // echo '<pre>';
        // print_r($newPost->getvalue());
    }
}
