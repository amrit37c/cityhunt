
<?php $__env->startSection('content'); ?>
<div class="login-background">
    <div class="container">
        <div class="row">
            <div class="col-md-4">

            </div>
            <div class="col-md-4 center">
                <div class="login-form-bck">
                    
                    <img src="<?php echo e(asset('assets/images/cityHUNT-logo-2020.svg')); ?>" class="login-logo">
                </p>
                <p>
                    <input type="text" placeholder="Name" class="login-inputs" id="name_field">
                </p>
                    <p>
                    <input type="text" placeholder="Email" class="login-inputs" id="email_field">
                </p>
                    <p>
                    <input type="password" placeholder="Password" class="login-inputs" id="password_field">
                        
                    </p>
                    <input type="password" placeholder="Re-type Password" class="login-inputs" id="re_type_password_field" onkeyup="signKeyUp(event)">
                    <p>
                    <button class="login-btn" onclick="signup()">CREATE ACCOUNT</button>
					</p>
                </div>
                <div>
                    
                </div>
                <a href="<?php echo e(URL::route('login')); ?>"id="create-acc">Login</a>

            </div>
            <div class="col-md-4">

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/d190129k/public_html/deepak/laravelfirebase/resources/views/register.blade.php ENDPATH**/ ?>