
<?php $__env->startSection('content'); ?>
<div class=" login-background">
    <div class="container dashboard-background">
        <div class="container">
            <div class="row">
                <div class="col-md-3 center">
                    <img src="<?php echo e(asset('assets/images/cityHUNT-logo-2020.svg')); ?>" class="login-logo dashboard-logo">
                    <a class="game-link" href="<?php echo e(route('games.create')); ?>">
                        <p class="createGame-input">CREATE NEW GAME </p>
                    </a>
                    <input type="text" placeholder="search" class="gameCreate-input"><br><br>
                </div>
                <div class="col-md-9">
                    <span class="header-game">GAMES</span>
                    <button class="btn btn-success btn-sm" style="float:right;margin:5px 0"
                        onclick="logout()">Logout</button>
                    <br>

                    <div id="tooltip"></div>
                    <table class="table table-bordered game-table create-game-table" id="myTable">
                        <thead>
                            <tr>
                                <th>Game Name</th>
                                <th>Date</th>
                                <th>Tags</th>
                                <th>Updated</th>
                                <th>Game Code</th>
                            </tr>
                        </thead>
                        <tbody id="accordion" class="custom-accordion">
                            <?php
                            $i = 1;
                            ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="cursor: pointer;">
                                    <div class="custom-card-header collapsed" data-toggle="collapse"
                                        data-target="#collapseOne<?php echo e($i); ?>">
                                        <a class="card-title1"><?php echo e($item['game_title'] ?? ''); ?></a>
                                    </div>
                                    <div id="collapseOne<?php echo e($i); ?>" class="collapse" data-parent="#accordion">
                                        <br>
                                        <div class="game-btns">
                                            <a href="<?php echo e(route('games.edit',[$key])); ?>">
                                                <button class="game-btn-name btn-sm">Edit Game</button></a>
                                            &nbsp;&nbsp;
                                            <a href="#" data-toggle="tooltip" title="This will create a new game.">
                                                <button class="game-btn-name btn-sm">Clone Game</button></a>
                                            &nbsp;&nbsp;
                                            <a href="teams.html"> <button class="game-btn-name btn-sm">Team</button></a>
                                            &nbsp;&nbsp;
                                            <a href="stream.html"> <button
                                                    class="game-btn-name btn-sm">Stream</button></a>
                                            &nbsp;&nbsp;
                                            <a href="monitor.html"> <button
                                                    class="game-btn-name btn-sm">Monitor</button></a>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo e(date("d M-y H:i A", strtotime($item['date'])) ?? ''); ?></td>
                                <td><?php echo e($item['game_tags'] ?? ''); ?></td>
                                <td><?php echo e($item['moderators'] ?? ''); ?></td>
                                <td><?php echo e($item['game_code'] ?? ''); ?></td>
                            </tr>
                            <?php
                            $i++;
                            ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/d190129k/public_html/deepak/laravelfirebase/resources/views/games/index.blade.php ENDPATH**/ ?>