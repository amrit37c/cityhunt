
<?php $__env->startSection('content'); ?>   
<div class="container homec">

<div class="row">

  <div class="col-md-3 center cityhunt-colmn">
    <img src="<?php echo e(asset('assets/images/cityHUNT-logo-2020.svg')); ?>" class="login-logo dashboard-logo">
    <input type="text" placeholder="search" class="gameCreate-input chlng">
    <div class="select-text">
      <select class="dropdown-challenge">
        <option>Jump TO Challenge</option>
        <option>Jump TO Challenge</option>
        <option>Jump TO Challenge</option>
        <option>Jump TO Challenge</option>
        <option>Jump TO Challenge</option>
      </select>

      <p class="createGame-input"><a href="#" data-toggle="tooltip" data-placement="bottom"
          title="On click on Add button a user can create New Challenge" class="tooltip_team">Add new
          Challenge</a></a></p>
    </div>
  </div>

 
  <div class="col-md-9">
  <form id="myform" method="POST" action="<?php echo e(route('games')); ?>" enctype="multipart/form-data" autocomplete="off"> 
  <?php echo e(csrf_field()); ?>

    <div class="row header header-game team-header">
      <div class="col-md-8">
        <span class="game-header-font">GAME TITLE</span>
        <input type="text" name="game_title" class="challenge-search-input" value="NYC Coca-Cola Hunt">

        <div class=" header-line-height">
          <span class="game-header-font">Tags</span>
          <input type="text" name="game_tags" class="challenge-moderator-input tags-inpt challenge-search-input" value="NYC Unlock Coca-Cola Hunt">
          <span class="game-header-font">GAME CODE</span>
          <input type="text" name="game_code" class="challenge-moderator-input game-code-inpt challenge-search-input" value="yolos22">
        </div>
      </div>
      <div class="col-md-4 remove-padding">
        <div class="moderator-div">
          <span class="game-header-font">MODERATORS</span>
          <input type="text" name="moderators" class="challenge-search-input challenge-moderator-input moderate-inpt" value="Elle,Ben,Henna">
        </div>
        <div class="leadarboard-div header-line-height">
          <span class="game-header-font toogle-btn ">LEADERBOARD</span>
          <label class="switch active-toogle leaderboard-label">
          <input type="checkbox" name="leaderboard" class="my_tgl_blue">
          <span class="slider round"></span>
    </label>

    <span class="game-header-font toogle-btn active-btn-header">ACTIVE</span>
      <label class="switch active-toogle active-header-label">
        <input type="checkbox" name="active_deactive" class="my_tgl_blue" checked>
        <span class="slider round"></span>
      </label>
        </div>
      </div>
    </div>

    <!-- ############ Challange One 1 ############ -->

    <div class="forms body-chl first-challenge">
      <div class="form_one input-form">
        <div class="row">
          <div class="col-md-5">
    
            <div class="challange_badge_div row">
              <div class="left_challange_badge_div">
                <p> Challenge </p>
                <input type="text" value="1" class="chlng-val" maxlength="2" name="challenge">
              </div>
              <div class="challange_badge_input">
                <input type="text" placeholder="Challange Title" name="challenge_title">
              </div>
            </div>
            <img class="img_br_news" src="<?php echo e(asset('assets/images/br_news.jpg')); ?>">
            <span>
              <select id="optionType" name="challenge_type">
                <option value="">Choose Option</option>
                <option value="txt">Text</option>
                <option value="video">Video</option>
                <option value="photo">Photo</option>
                <option value="mcq">Multiple Choice</option>
                <option value="qrc">QR Code</option>
                <option value="tri">Trivia</option>
              </select>
            </span>

        <div class="text_qsn_btn">
          <p> Does this clue have a location ? </p>
          <label class="switch location-switch check_style">
          <input type="checkbox" name="clue_location">
          <span class="slider round"></span>
          </label>
        </div>
    
    <!--video-->
    <div class="video box">
        <input type="text" class="location_img_input" placeholder="Location" name="location">
        <button type="button" class="search-btn"> Search </button>
        <img id="img_loc" src="<?php echo e(asset('assets/images/Group 43.svg')); ?>">
    </div>
    <!--video-->

    <div class="left-icon">
      <i class="fa fa-file-o fnt_asm_stngs fa-lg" aria-hidden="true"></i>
      <i class="fa fa-clone fnt_asm_stngs fa-lg aaa" aria-hidden="true"></i>
      <i class="fa fa-file-o fnt_asm_stngs fa-lg" aria-hidden="true"></i>
      <i class="fa fa-trash-o fnt_asm_stngs fa-lg" aria-hidden="true"></i>
    </div>

    <span class="lock_challange lock_challange_one">
      <span> Locked by Challange</span>
      <span class="p_select">
      <select name="locked_by">
        <option>None</option>
      </select>
      </span>
    </span>
    
    
          </div>
    
    <div class="col-md-7">
    
    <div class="div_main_input">
      <div id="editor" class="pell" name="challenge_description"></div>
    </div>
    
    <!--text-->
    <div class="txt box">
      <textarea placeholder="Answers" class="answers_input_div" name="challenge_answer"></textarea>
    </div>
    <!--text-->
    
    <!--video-->
    <div class="video box">
      <div class="row">
        <div class="col-md-12">
        <span class="sub-para"> Is there a Video/Image example? </span>
          <label class="switch video-label check_style">
          <input type="checkbox" name="video_image">
          <span class="slider round"></span>
          </label>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <span class="sub-para"> Example video Address </span>
           <span> <input class="example-video-addr" name="video_image_url"></span>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
        <span class="sub-para"> Video length </span>
          <select  class="example-video-section" name="video_length">
          <option value="20s">20s</option>
          <option value="10s">10s</option>
          </select>
        </div>
      </div><br><br>
    </div>
    <!--video-->
    
    <!--Image-->
    <div class="row photo box">
      <div class="col-md-6">
        <div class="row">
          <div class="col-md-6"><input class="challenge-five-input" name="image_url"></div>
          <div class="col-md-6"><button class="upload-png-btn">Upload Png</button></div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="align-center">
          <p class="imge-overlay img-overly-second">Image Overlay Is:</p>
          <span class="imge-overlay">Floating</span>
          <span>
            <label class="switch check_style floating-label">
              <input type="checkbox" name="image_overlay">
              <span class="slider round"></span>
            </label>
          </span>
          <span class="imge-overlay">Fullscreen</span>
        </div>
      </div>
    </div>
    <!--Image-->
    
    <!--MCQ-->
    <div class="mcq box">
      <div class="row">
        <div class="col-md-12"><input class="challenge-six-inputs"></div>
        <label class="challengesix-labelone switch check_style">
        <input type="checkbox" name="mcq_ans_1">
        <span class="slider round"></span>
        </label>
        <span class="chllengesix-answer">Answer "1</span>
      </div>
      <div class="row">
        <div class="col-md-12"><input class="challenge-six-inputs"></div>
        <label class="challengesix-labelone switch check_style">
        <input type="checkbox" name="mcq_ans_2">
        <span class="slider round"></span>
        </label>
        <span class="chllengesix-answer">Answer "2</span>
      </div>
      <div class="row">
        <div class="col-md-12"><input class="challenge-six-inputs"></div>
        <label class="challengesix-labelone switch check_style">
        <input type="checkbox" name="mcq_ans_3">
        <span class="slider round"></span>
        </label>
        <span class="chllengesix-answer">Answer "3</span>
      </div>
    </div>
    <!--MCQ-->
    
      <div class="row">
        <div class="col-md-12">
          <div class="Show_submission">
            <p class="show-sub-para"> Show submission in Streams: </p>
            <label class="switch body-switches check_style">
            <input type="checkbox" id="saveform" onChange="formsubmit();">
            <span class="slider round"></span>
            </label>
          </div>
        </div>
      </div>

    </div>
          
        </div>
      </div>
    </div>
    <!-- <input type='button' value='Add new' name='submit' onclick="formsubmit();"> -->
    <input type='button' id="but_add1" value='Add new challenge' >
    </form>
  </div>
  

</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#optionType").change(function(){
    $(this).find("option:selected").each(function(){
      var optionValue = $(this).attr("value");
      if(optionValue){
        $(".box").not("." + optionValue).hide();
        $("." + optionValue).show();
        if(optionValue == 'photo' || optionValue == 'qrc' || optionValue == 'tri' ){
          $(".txt").show();
        }
      } else{
        $(".box").hide();
        $(".txt").show();
      }
    });
  }).change();
});

function formsubmit(){
  formData = $('#myform').serialize();  
  $.ajax({
      url : "<?php echo e(route('games')); ?>",
      type: "POST",
      data : formData,
      headers: {
          'X-CSRF-Token': '<?php echo e(csrf_token()); ?>',
      },
      success: function(response)
      {                                                       
        alert(response['success']);
        window.location.href = "<?php echo e(route('dashboard')); ?>";
      }
  });
}



</script>
  
<script>
  $(document).ready(function(){
	 $('#but_add').click(function(){
	 
	  // Create clone of <div class='input-form'>
	  var newel = $('.input-form:last').clone(true);
	 
	  // Add after last <div class='input-form'>
	  $(newel).insertAfter(".input-form:last");
	 });
  });
</script>
<?php echo $__env->yieldSection(); ?>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravelfirebase\resources\views/games/create.blade.php ENDPATH**/ ?>