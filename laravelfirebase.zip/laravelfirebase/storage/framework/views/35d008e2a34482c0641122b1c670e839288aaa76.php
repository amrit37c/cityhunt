
<?php $__env->startSection('content'); ?>
<div class=" login-background">
  <div class="container dashboard-background">
    <div class="container">
      <div class="row">
        <div class="col-md-3 center">
          <img src="<?php echo e(asset('assets/images/cityHUNT-logo-2020.svg')); ?>" class="login-logo dashboard-logo">
          <a class="game-link" href="<?php echo e(URL::route('create')); ?>"> <p class="createGame-input">CREATE NEW GAME </p></a>
          <input type="text" placeholder="search" class="gameCreate-input"><br><br>
        </div>
        <div class="col-md-9">
          <span class="header-game">GAMES</span>
          <button class="btn btn-success btn-sm" style="float:right;margin:5px 0" onclick="logout()">Logout</button>
          <br>
          <table class="table table-bordered game-table create-game-table">
              
              <tr>
                <th>Game Name</th>
                <th>Date</th>
                <th>Tags</th>
                <th>Updated</th>
                <th>Game Code</th>
              </tr>
              
              <tbody id="myTable">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr data-toggle="collapse" href="#collapseOne<?php echo e($key); ?>">
                    <td>
                        <div id="accordion" class="custom-accordion">
                            <div class="custom-card-header collapsed"  title="Click Over">
                              <a class="card-title1"><?php echo e($item['game_title'] ?? ''); ?></a>
                          </div>
                        </div>
                    </td>
                    <td><?php echo e(date("d M-y H:i A", strtotime($item['date'])) ?? ''); ?></td>
                    <td><?php echo e($item['game_tags'] ?? ''); ?></td>
                    <td><?php echo e($item['moderators'] ?? ''); ?></td>
                    <td><?php echo e($item['game_code'] ?? ''); ?></td>
                  </tr>
                  <tr>
                    <td colspan="12" class="custom-column">
                      <div id="collapseOne<?php echo e($key); ?>" class="collapse" data-parent="#accordion">
                        <div class="game-btns">
                        <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                        <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone Game</button></a>
                        <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                        <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                        <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                        </div>
                      </div>
                      </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              </table>

              <!--<div class="col-md-12 text-center">
                <ul class="pagination pagination-lg pager" id="myPager"></ul>
              </div>-->
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravelfirebase\resources\views/games/index.blade.php ENDPATH**/ ?>